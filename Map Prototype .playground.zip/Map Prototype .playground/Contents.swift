import UIKit
import MapKit
import PlaygroundSupport
class MapViewController:UIViewController{
    let mapView = MKMapView()
override func viewDidLoad() {
        super.viewDidLoad()
    
    
        let brandi = CLLocationCoordinate2DMake(40.836724, 14.2468766)
        let camera = MKMapCamera(lookingAtCenter: brandi, fromDistance: 1000, pitch: 45, heading: 315)
        mapView.camera = camera
        mapView.mapType = .satelliteFlyover
        let annotation = MKPointAnnotation()
        annotation.coordinate = brandi
    //annotation.title = "Pizzeria Brandi"
    //annotation.subtitle = "The First Pizza Margherita(1889)"
        mapView.addAnnotation(annotation)
        //add to view
        mapView.frame = view.frame
        view.addSubview(mapView)
    let button = UIButton(frame: view.frame)
    button.addTarget(self, action: #selector(animateMap(_:)), for: .touchUpInside )
    view.addSubview(button)
    animateMap(button)
    }
    
    @IBAction func animateMap(_ sender:UIButton){
        
        var frames = 0
        let timer = Timer.scheduledTimer(withTimeInterval: 1.0/30.0, repeats: true, block: { (timer) in
            self.mapView.camera.heading += 1.0
            frames += 1
            if frames == 90 {
                timer.invalidate()
            }
        })
    }
}

PlaygroundPage.current.liveView = MapViewController()
